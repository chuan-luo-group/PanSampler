(set-info :smt-lib-version 2.6)
(set-logic QF_BV)
(set-info :source |
We try to verify a verification condition for a signed multiplication
overflow detection unit, which is described in
"Combined Unsigned and Two's Complement Saturating Multipliers"
by M. Schulte et al.

Let n be the bit-width, which is even.
We try to verify the following.
If the n/2 most significant bits of the operands are zero, then
the overflow detection unit must not yield an overflow.
Obviously, this is an invalid verification condition
as for example 0011 * 0011 = 1001 overflows in the signed case, which
is correctly detected by the unit.

Bit-width: 32

Contributed by Robert Brummayer (robert.brummayer@gmail.com).
|)
(set-info :category "industrial")
(set-info :status sat)
(declare-fun v1 () (_ BitVec 32))
(declare-fun v2 () (_ BitVec 32))
(assert (let ((?v_0 ((_ extract 31 31) v1)) (?v_2 ((_ extract 31 31) v2))) (let ((?v_1 (concat (ite (= (_ bv1 1) ((_ extract 0 0) ?v_0)) (_ bv2147483647 31) (_ bv0 31)) ?v_0)) (?v_3 (concat (ite (= (_ bv1 1) ((_ extract 0 0) ?v_2)) (_ bv2147483647 31) (_ bv0 31)) ?v_2))) (let ((?v_4 (bvand (bvnot (bvand (bvnot v1) (bvnot ?v_1))) (bvnot (bvand v1 ?v_1)))) (?v_6 (bvand (bvnot (bvand (bvnot v2) (bvnot ?v_3))) (bvnot (bvand v2 ?v_3))))) (let ((?v_5 ((_ extract 30 30) ?v_6))) (let ((?v_7 (bvand (bvnot ?v_5) (bvnot ((_ extract 29 29) ?v_6))))) (let ((?v_8 (bvand ?v_7 (bvnot ((_ extract 28 28) ?v_6))))) (let ((?v_9 (bvand ?v_8 (bvnot ((_ extract 27 27) ?v_6))))) (let ((?v_10 (bvand ?v_9 (bvnot ((_ extract 26 26) ?v_6))))) (let ((?v_11 (bvand ?v_10 (bvnot ((_ extract 25 25) ?v_6))))) (let ((?v_12 (bvand ?v_11 (bvnot ((_ extract 24 24) ?v_6))))) (let ((?v_13 (bvand ?v_12 (bvnot ((_ extract 23 23) ?v_6))))) (let ((?v_14 (bvand ?v_13 (bvnot ((_ extract 22 22) ?v_6))))) (let ((?v_15 (bvand ?v_14 (bvnot ((_ extract 21 21) ?v_6))))) (let ((?v_16 (bvand ?v_15 (bvnot ((_ extract 20 20) ?v_6))))) (let ((?v_17 (bvand ?v_16 (bvnot ((_ extract 19 19) ?v_6))))) (let ((?v_18 (bvand ?v_17 (bvnot ((_ extract 18 18) ?v_6))))) (let ((?v_19 (bvand ?v_18 (bvnot ((_ extract 17 17) ?v_6))))) (let ((?v_20 (bvand ?v_19 (bvnot ((_ extract 16 16) ?v_6))))) (let ((?v_21 (bvand ?v_20 (bvnot ((_ extract 15 15) ?v_6))))) (let ((?v_22 (bvand ?v_21 (bvnot ((_ extract 14 14) ?v_6))))) (let ((?v_23 (bvand ?v_22 (bvnot ((_ extract 13 13) ?v_6))))) (let ((?v_24 (bvand ?v_23 (bvnot ((_ extract 12 12) ?v_6))))) (let ((?v_25 (bvand ?v_24 (bvnot ((_ extract 11 11) ?v_6))))) (let ((?v_26 (bvand ?v_25 (bvnot ((_ extract 10 10) ?v_6))))) (let ((?v_27 (bvand ?v_26 (bvnot ((_ extract 9 9) ?v_6))))) (let ((?v_28 (bvand ?v_27 (bvnot ((_ extract 8 8) ?v_6))))) (let ((?v_29 (bvand ?v_28 (bvnot ((_ extract 7 7) ?v_6))))) (let ((?v_30 (bvand ?v_29 (bvnot ((_ extract 6 6) ?v_6))))) (let ((?v_31 (bvand ?v_30 (bvnot ((_ extract 5 5) ?v_6))))) (let ((?v_32 (bvand ?v_31 (bvnot ((_ extract 4 4) ?v_6))))) (let ((?v_33 (bvand ?v_32 (bvnot ((_ extract 3 3) ?v_6))))) (let ((?v_34 (bvand ?v_33 (bvnot ((_ extract 2 2) ?v_6)))) (?v_35 (bvmul (concat (ite (= (_ bv1 1) ?v_0) (_ bv1 1) (_ bv0 1)) v1) (concat (ite (= (_ bv1 1) ?v_2) (_ bv1 1) (_ bv0 1)) v2)))) (not (= (bvand (bvand (ite (= ((_ extract 31 16) v1) (_ bv0 16)) (_ bv1 1) (_ bv0 1)) (ite (= ((_ extract 31 16) v2) (_ bv0 16)) (_ bv1 1) (_ bv0 1))) (bvnot (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvand (bvnot (bvand ((_ extract 1 1) ?v_4) ?v_5)) (bvnot (bvand ((_ extract 2 2) ?v_4) (bvnot ?v_7)))) (bvnot (bvand ((_ extract 3 3) ?v_4) (bvnot ?v_8)))) (bvnot (bvand ((_ extract 4 4) ?v_4) (bvnot ?v_9)))) (bvnot (bvand ((_ extract 5 5) ?v_4) (bvnot ?v_10)))) (bvnot (bvand ((_ extract 6 6) ?v_4) (bvnot ?v_11)))) (bvnot (bvand ((_ extract 7 7) ?v_4) (bvnot ?v_12)))) (bvnot (bvand ((_ extract 8 8) ?v_4) (bvnot ?v_13)))) (bvnot (bvand ((_ extract 9 9) ?v_4) (bvnot ?v_14)))) (bvnot (bvand ((_ extract 10 10) ?v_4) (bvnot ?v_15)))) (bvnot (bvand ((_ extract 11 11) ?v_4) (bvnot ?v_16)))) (bvnot (bvand ((_ extract 12 12) ?v_4) (bvnot ?v_17)))) (bvnot (bvand ((_ extract 13 13) ?v_4) (bvnot ?v_18)))) (bvnot (bvand ((_ extract 14 14) ?v_4) (bvnot ?v_19)))) (bvnot (bvand ((_ extract 15 15) ?v_4) (bvnot ?v_20)))) (bvnot (bvand ((_ extract 16 16) ?v_4) (bvnot ?v_21)))) (bvnot (bvand ((_ extract 17 17) ?v_4) (bvnot ?v_22)))) (bvnot (bvand ((_ extract 18 18) ?v_4) (bvnot ?v_23)))) (bvnot (bvand ((_ extract 19 19) ?v_4) (bvnot ?v_24)))) (bvnot (bvand ((_ extract 20 20) ?v_4) (bvnot ?v_25)))) (bvnot (bvand ((_ extract 21 21) ?v_4) (bvnot ?v_26)))) (bvnot (bvand ((_ extract 22 22) ?v_4) (bvnot ?v_27)))) (bvnot (bvand ((_ extract 23 23) ?v_4) (bvnot ?v_28)))) (bvnot (bvand ((_ extract 24 24) ?v_4) (bvnot ?v_29)))) (bvnot (bvand ((_ extract 25 25) ?v_4) (bvnot ?v_30)))) (bvnot (bvand ((_ extract 26 26) ?v_4) (bvnot ?v_31)))) (bvnot (bvand ((_ extract 27 27) ?v_4) (bvnot ?v_32)))) (bvnot (bvand ((_ extract 28 28) ?v_4) (bvnot ?v_33)))) (bvnot (bvand ((_ extract 29 29) ?v_4) (bvnot ?v_34)))) (bvnot (bvand ((_ extract 30 30) ?v_4) (bvnot (bvand ?v_34 (bvnot ((_ extract 1 1) ?v_6))))))) (ite (= ((_ extract 32 32) ?v_35) ((_ extract 31 31) ?v_35)) (_ bv1 1) (_ bv0 1))))) (_ bv0 1))))))))))))))))))))))))))))))))))))
(check-sat)
(exit)
