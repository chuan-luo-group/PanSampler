(set-info :smt-lib-version 2.6)
(set-logic QF_ABV)
(set-info :source |
Ivan Jager <aij+nospam@andrew.cmu.edu>

|)
(set-info :category "industrial")
(set-info :status sat)
(declare-fun mem_35_84 () (Array (_ BitVec 32) (_ BitVec 8)))
(declare-fun R_EBP_0_60 () (_ BitVec 32))
(declare-fun R_ESP_1_58 () (_ BitVec 32))
(assert (let ((?v_2 (bvsub R_ESP_1_58 (_ bv4 32)))) (let ((?v_5 (bvadd ?v_2 (_ bv4 32)))) (let ((?v_3 (bvadd (bvsub ?v_5 (_ bv4 32)) (_ bv8 32))) (?v_0 (bvsub ?v_2 (_ bv4 32)))) (let ((?v_1 (store (store (store (store mem_35_84 (bvadd ?v_0 (_ bv3 32)) ((_ extract 7 0) (bvlshr R_EBP_0_60 (_ bv24 32)))) (bvadd ?v_0 (_ bv2 32)) ((_ extract 7 0) (bvlshr R_EBP_0_60 (_ bv16 32)))) (bvadd ?v_0 (_ bv1 32)) ((_ extract 7 0) (bvlshr R_EBP_0_60 (_ bv8 32)))) (bvadd ?v_0 (_ bv0 32)) ((_ extract 7 0) R_EBP_0_60)))) (let ((?v_4 (bvor (bvor (bvor (concat (_ bv0 24) (select ?v_1 (bvadd ?v_3 (_ bv0 32)))) (bvshl (concat (_ bv0 24) (select ?v_1 (bvadd ?v_3 (_ bv1 32)))) (_ bv8 32))) (bvshl (concat (_ bv0 24) (select ?v_1 (bvadd ?v_3 (_ bv2 32)))) (_ bv16 32))) (bvshl (concat (_ bv0 24) (select ?v_1 (bvadd ?v_3 (_ bv3 32)))) (_ bv24 32))))) (let ((?v_6 (store (store (store (store ?v_1 (_ bv134549039 32) ((_ extract 7 0) (bvlshr ?v_4 (_ bv24 32)))) (_ bv134549038 32) ((_ extract 7 0) (bvlshr ?v_4 (_ bv16 32)))) (_ bv134549037 32) ((_ extract 7 0) (bvlshr ?v_4 (_ bv8 32)))) (_ bv134549036 32) ((_ extract 7 0) ?v_4)))) (= (_ bv1 1) (bvand (ite (not (= (bvor (bvor (bvor (concat (_ bv0 24) (select mem_35_84 (bvadd R_ESP_1_58 (_ bv0 32)))) (bvshl (concat (_ bv0 24) (select mem_35_84 (bvadd R_ESP_1_58 (_ bv1 32)))) (_ bv8 32))) (bvshl (concat (_ bv0 24) (select mem_35_84 (bvadd R_ESP_1_58 (_ bv2 32)))) (_ bv16 32))) (bvshl (concat (_ bv0 24) (select mem_35_84 (bvadd R_ESP_1_58 (_ bv3 32)))) (_ bv24 32))) (bvor (bvor (bvor (concat (_ bv0 24) (select ?v_6 (bvadd ?v_5 (_ bv0 32)))) (bvshl (concat (_ bv0 24) (select ?v_6 (bvadd ?v_5 (_ bv1 32)))) (_ bv8 32))) (bvshl (concat (_ bv0 24) (select ?v_6 (bvadd ?v_5 (_ bv2 32)))) (_ bv16 32))) (bvshl (concat (_ bv0 24) (select ?v_6 (bvadd ?v_5 (_ bv3 32)))) (_ bv24 32))))) (_ bv1 1) (_ bv0 1)) (_ bv1 1))))))))))
(check-sat)
(exit)
